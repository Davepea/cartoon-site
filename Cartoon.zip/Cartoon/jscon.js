var surname, Firstname, age; 
function mySurname(){
    surname = prompt ("enter your surname") }
function myFirstname(){
    Firstname= prompt ("enter your Firstname") }
function myAge(){
    age = prompt ("enter your Age") }
const shoe = number
function myDetails(){document.getElementById('details').innerHTML='name is '  + Firstname +' '+ surname +''+ ',    Age is ' + age }
function myShoe(){
const  d = new Date().getHours();
let greetings;
if(d <= 2){
    greetings=alert('Goodmorning')
} 
else if(d <= 10){
    greetings=alert('Goodafternoon')
}

}