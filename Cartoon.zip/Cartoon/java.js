var name = prompt("What is youe name")
window.alert("name is " + name);
console.log("Thanks" + name +"for coming")
var number = prompt ("what is your age")
window.alert("you are " + number +"years old")
const days = 365;
totaldays = days * number
window.alert("you have used " + totaldays + " days on earth ")

let a, b, c, d, e, f, g;
a=250;
b=250;
c=10;
d= a + b /c;
e=1000;
f=5;
g=e*f;
function myFunction(){document.getElementById('solve').innerHTML='250 + 250/10=' +' '+ d }
function myCar(){document.getElementById('cool').innerHTML='Adebayo peace'}
function myPop(){window.alert('SUNMENCE')}
function myCole(){document.getElementById('school').innerHTML='1000 * 5 =' +' '+ g}
function myGoal(){ document.getElementById('cola').innerHTML='Goodbye to Sunmence';}


function myImage(){document.getElementById('img').src="rr.jpg"}
function mySurname(){var name = prompt ("enter your surname") }
function myFirstname(){var surname = prompt ("enter your Firstname") }
function myAge(){var number = prompt ("enter your Age") }
function myDetails(){window.alert("name is " + name)}
